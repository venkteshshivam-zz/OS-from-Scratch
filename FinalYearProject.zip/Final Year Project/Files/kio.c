void prnt(char* buff){
	

	interrupt(0x21,0,buff,0,0);

}
int main()
{
	prnt("Kashif is working");
	return 0;
}
