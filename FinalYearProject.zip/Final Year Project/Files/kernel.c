void printString(char*);
void readString(char*);
void readSector(char* buffer, int sector);
void writeSector(char* buffer, int sector);
int mod(int a, int b);
int div(int a, int b);
void handleInterrupt21 (int AX, int BX, int CX, int DX);
void readFile(int* fileName,int* buffer);
void printChar(char ch);
void prtInt(int i);
int strComp(int* buffer, char* fileName);
void executeProgram(char* name, int segment); 
void terminate();
void deleteFile(char* name);
void writeFile(int* name, int* buffer, int numberOfSectors);
void getDirectory();
void clear(char*,int);
void exe(char*, int);


main(){
	int i;
	char buff[13312];
	char b[512];
	makeInterrupt21();

	interrupt(0x21, 4, "shell\0", 0x2000, 0);	

    while(1){

    }
} 

void handleInterrupt21 (int AX, int BX, int CX, int DX){
		int ah;
	
		ah = AX >> 8;

		if (ah == 9){
			interrupt(0x10, 0xe*256+'H', 0, 0, 0);
			interrupt(0x10, 0xe*256+'e', 0, 0, 0);
			interrupt(0x10, 0xe*256+'l', 0, 0, 0);
			interrupt(0x10, 0xe*256+'l', 0, 0, 0);
			interrupt(0x10, 0xe*256+'o', 0, 0, 0);
			interrupt(0x10, 0xe*256+' ', 0, 0, 0);
			interrupt(0x10, 0xe*256+'W', 0, 0, 0);
			interrupt(0x10, 0xe*256+'o', 0, 0, 0);
			interrupt(0x10, 0xe*256+'r', 0, 0, 0);
			interrupt(0x10, 0xe*256+'l', 0, 0, 0);
			interrupt(0x10, 0xe*256+'d', 0, 0, 0);
			interrupt(0x10, 0xe*256+'!', 0, 0, 0);
		}
		else if (ah == 0x4C){
			terminate();
		}
	
        if (AX == 0){
            printString(BX);
        }
        else if (AX ==1){
            readString(BX);
        }
        else if(AX == 2){
			
            readSector(BX,30);
        }
		else if (AX == 3){
			
			readFile(BX, CX);
		}
		else if (AX == 4){
			
			executeProgram(BX,CX);
		}
		else if (AX == 5){
			terminate();
		}
		else if (AX == 6){
			
			writeSector(BX,CX);
		}
		else if (AX == 7){
			deleteFile(BX);
		}
		else if (AX == 8){
			
			writeFile(BX, CX, DX);
		}
		else if (AX == 9){
			getDirectory();
		}
		else if (AX == 10){
			
			exe(BX,CX);
		}
        else{
            printString("Invalid interrupt!\0");
        }
}



void exe(char* name, int our_segment){
	char exeFile[13312];
	int relocEntries, ss, sp, ip, cs, offset;
	int i,j, headerOffset, seg;
	
	
	readFile(name,exeFile);
	
    offset = (exeFile[25]*256)+exeFile[24];
	
    relocEntries = (exeFile[7]*256)+exeFile[6];
	
	ip = (exeFile[21]*256)+exeFile[20];		
	
    cs = (exeFile[23]*256)+exeFile[22];
	
	ss = (exeFile[15]*256)+exeFile[14];
	
    sp = (exeFile[17]*256)+exeFile[16];
	
	
	
	i = 0;
	j = 3;
	while(i<relocEntries){
		seg = exeFile[offset+j] + exeFile[offset+1+j]*256;
		seg = seg + our_segment;
		exeFile[offset+j] = seg && 0xff;
		exeFile[offset+1+j] = (seg >> 8)&&0xff;
		i++;
		j+=3;
	}

	
	headerOffset = 28;
	for (j=headerOffset;j<13312-headerOffset;j++){
		putInMemory(our_segment,j-headerOffset,exeFile[j]);
	}

	
	launchProgramExe(our_segment,cs+our_segment,ss+our_segment,ip,sp);
	
}

void executeProgram(char* name, int segment){ 
	int i;
	int address;
	char readingBuffer[13312];

	readFile(name, readingBuffer);

	for (i=0; i<13312;i++){
		putInMemory(segment,i,readingBuffer[i]);
	} 

	launchProgram(segment);

}

void terminate(){
	char shell[6];
	shell[0] = 's';
	shell[1] = 'h';
	shell[2] = 'e';
	shell[3] = 'l';
	shell[4] = 'l';
	shell[5] = 0x0;
	interrupt(0x21,4,shell,0x2000,0);
}

void getDirectory(){
	char buff[512];
	char dirBuff[512];
	int i,j;
	int index = 0;
	for(i=0;i<512;i++){
		buff[i] = 0x0;
		dirBuff[i]=0x0;
	}
	
    readSector(dirBuff, 2); 
	
	for(i=0;i<16;i++){
		 
		if (dirBuff[32*i] != 0x0){
			
			for (j=0; j < 6; j++){
				buff[index] = dirBuff[j+32*i];
				index++;
			}
			
			buff[index] = '\r';
			index++;
			buff[index] = '\n';
			index++;
		}
	}
	for(i=0;i<512;i++){
		printChar(buff[i]);
	}
	return;
	
}


void writeFile(char* name,char* buffer, int numberOfSectors) {
	char map[512];
	char directory[512];
	int directoryLine,j,k, index, diff;
	int nameLen = 0;
	int sectorNum;
	char subBuff[512];
	int iterator = 0;
	int foundFree = 0;
	int nameInts[7];
	int i,h;
	int kVal;

	
	readSector(map,1);
	readSector(directory,2);
	
	
     	for (directoryLine = 0; directoryLine < 16; directoryLine++){
		
		if (directory[32*directoryLine] == 0x00){
			foundFree = 1;
			break;
		}
	}
	if (foundFree == 0){
		printString("Didn't find empty location for file.");
		return;
	}

		
	while(name[nameLen] != '\0' && name[nameLen] != 0x0){
		nameLen++;
	}
	
	for (j=0;j<nameLen;j++){
		directory[32*directoryLine+j] = name[j];
	}
	
	if (nameLen < 6){
		diff = 6-nameLen;
		for(j=0;j<diff;j++){
			index = j+nameLen;
			directory[32*directoryLine+index] = 0x0;
		}
	}

	
	for (k = 0; k < numberOfSectors; k++){

		
		sectorNum = 0;
		while(map[sectorNum] != 0x0){
			sectorNum++;
		}
		if (sectorNum==26)
		{
			printString("Not enough space in directory entry for file\n");
			return;
		}
		
		map[sectorNum] = 0xFF;
		
		directory[32*directoryLine+6+k] = sectorNum;
		
		for(j=0;j<512;j++){
			kVal = k+1;
			subBuff[j] = buffer[j*kVal];
		}
		writeSector(subBuff,sectorNum);
	}
	
	writeSector(map,1);
	writeSector(directory,2);
}

void deleteFile(char* name){
	char map[512];
	char directory[512];
	int sectors[27];
	int sectorCount = 0;
	int i, j, k, fileFound, index;
	int sectNum;
	int sector;
	
	
	readSector(map,1);
	readSector(directory,2);



	fileFound = strComp(directory,name);

	if (fileFound!=0){

		
		
		for(i=0;i<6;i++){
			directory[fileFound*32+i] = 0x00;
		}
		index = fileFound*32+6;
		for (j=0;j<26;j++){
		/*while(directory[index]!=0x0){*/
			sectors[j] = directory[index+j];
			directory[index+j] = 0x00;
			sectorCount++;
			/*index++;*/
		
		}
		sectors[26] = 0x0;

		


		for(k=0;k<sectorCount;k++){
			sector = sectors[k];
			if(sector == 0){
				break;
			}

			map[sector] = 0x00;

		}
	}
	else{
		printString("File not found!");
	}
	
	
	writeSector(map,1);
	writeSector(directory,2);
}

void readFile(char* fileName,char* buffer){ 
    int fileFound;
    int nameCt = 0;
	int index, k,h;
	int sectors[27];
	int j = 0;
	int i;
	int buffAddress = 0;
	

   
    readSector(buffer, 2);  

    
	fileFound = strComp(buffer,fileName);

	if (fileFound!=0){

		
		index = fileFound*32+6;
		for (j=0;j<26;j++){
			sectors[j] = buffer[index+j];
			
		}

		sectors[26] = 0;
		k = 0;
		while(sectors[k]!=0x0){
			readSector(buffer+buffAddress,sectors[k]);
			buffAddress += 512;
			k++;
		}
		
	}
	else{
		printString("File Not Found!");
		return;
	}		

}

void writeSector(char* buffer, int sector){
	
    
        int relSector = mod(sector,18) + 1;
     
        int op = div(sector,18);
        int head = mod(op,2);

        int track = div(sector,36);

        interrupt(0x13,3*256+1,buffer,track*256+relSector,head*256+0);
}

void readSector(char* buffer, int sector){ 

       
        int relSector = mod(sector,18) + 1;
        int op = div(sector,18);
        int head = mod(op,2);
        int track = div(sector,36);
        interrupt(0x13,2*256+1,buffer,track*256+relSector,head*256+0);


}

int strComp(char* buffer, char* fileName){ 
	int i, j;

	int checkFound = 0;


     for (i = 0; i < 16; i++)
 		{
		if (buffer[32*i] != 0x0){
			for (j=0; j < 6; j++){
				

				if (buffer[j+32*1] == 0x0 || buffer[j+32*1] == '\r' || buffer[j+32*1] == '\n' || fileName[j] == 0x0 || fileName[j] == '\r' || fileName[j] == '\n'){
					break;
				}
				else if (buffer[j+32*i] == fileName[j]){
					checkFound = 1;	
				}
				else {
					checkFound = 0;
					break;
				}
				
			}
		 	
			if (checkFound == 1){

				 return i;
			}
			else{
				/*printString("Next check");*/
			
			}
		}
		}
			 if (checkFound == 0){
				 for (i=0;i<13312;i++){
					buffer[i] = 0x0;
				 }
				
				 
				return 0;
			 }

	 

}

int mod(int a, int b){
    while(a >= b){
        a = a - b;
    }
    return a;
}

int div(int a, int b){
    int q = 0;
    while(q*b <=a){
        q = q+1;
    }
    return q-1;

}

void readString(char* buff){
    int dashn = 0xa;
    int endStr = 0x0;
    int enter = 0xd;
    int backsp = 0x8;
    int dashr = 0xd;
    int loop = 1;
    int count = 2;
    buff[0] = dashr;
    buff[1] = dashn;
    while(loop){
       
            int ascii = interrupt(0x16,0,0,0,0);
            if (ascii == enter){              
				buff[count] = 0x0;
                buff[count+1] = dashr;
                buff[count+2] = dashn;
                return;
            }
            else if (ascii == backsp){
                if (count > 1){
                    buff[count] = 0x0;
                    count--;
                    interrupt(0x10,0xe*256+0x8,0,0,0);
                    count++;
                    interrupt(0x10,0xe*256+0x0,0,0,0);
                    count--;
                    interrupt(0x10,0xe*256+0x8,0,0,0);
                    
               }
            }
            else{
                buff[count] = ascii;
                interrupt(0x10, 0xe*256+ascii, 0, 0, 0);
                count++;
            }     
    }
}
    
void printString(char* chars){

   
    int i = 0;
    while(chars[i] != '\0'){
            int ch = chars[i];
            
		        interrupt(0x10, 0xe*256+ch, 0, 0, 0);
            i++;
    }


}
void clear(char* buff, int len){
	int i;
	for(i=0;i<len;i++){
		buff[i] = 0x0;
	}
}
void printChar(char ch){
	char* chars[2];
	chars[0] = ch;
	chars[1] = '\0';
	printString(chars);
}
void prtInt(int i){
	int* chars[2];
	chars[0] = i;
	chars[1] = '\0';
	printString(chars);
	
}


