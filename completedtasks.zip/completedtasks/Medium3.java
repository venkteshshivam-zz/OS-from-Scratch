package completedtasks;

// *********************
// Extract dates from text files using regular expression
// Medium-3
// Author: Venktesh Shivam Patel(B-03)
// **********************


import java.io.IOException;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;


/**
 * @author vshivamp
 *
 */
 class Medium3 {
	
	/**
	 *  empty constructor and not to be called.
	 */
	public Medium3() { }
	
	/**
	 * @param arg
	 * runtime input
	 * @throws IOException
	 * handles IO Exceptions
	 */

	public static void main(final String[] arg)throws IOException {
		
		
		FileReader fr = new FileReader("C:\\New folder\\T7input.txt");
		getDate(fr);
		fr.close();
	}
	
	/**
	 * @param fr
	 * stores file 
	 * @return
	 * returns list of extracted dates
	 * @throws IOException
	 * Handles IO Exception
	 */
	public static ArrayList<String> getDate(final FileReader fr)throws 
											IOException {
		
		String fileText = "";
		LineNumberReader lr = new LineNumberReader(fr);
		Medium3 m3 = new Medium3();
		m3.printNothing();
		String line = lr.readLine();
		
		// Converting file text to a string
		
		while (line != null) {				
		
			fileText = fileText + line;
			
			line = lr.readLine();
		}
		
		  ArrayList<String> listOfDates = new ArrayList<String>();
		
		  // Regular expression for extracting date
		  
		  Matcher m = Pattern.compile(
				  "(0[1-9]|[12][0-9]|3[01])[- /.]"
				  + "(0[1-9]|1[012])[- /.](19|20)\\d\\d")
				  .matcher(fileText);	
		  
		  while (m.find()) {
		    
		    listOfDates.add(m.group());
			 			  
		  }
		  
		// Printing all valid dates from ArrayList
			
		  for (String date: listOfDates) {
				System.out.println(date);
			}
		  return listOfDates;
		}
	
	
			/**
			 * This function is null and void.
			 */
			public void printNothing() {
		
				
			}	
	
	}

