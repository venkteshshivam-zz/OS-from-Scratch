package completedtasks;

//**********************
// Parse XML file using JAXP(JUnit test)
// Test Complex-2
// Author: Venktesh Shivam Patel(B-03)
// **********************

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import java.io.File;
import java.util.ArrayList;

import org.junit.Test;

/**
 * @author vshivamp
 *
 */
public class TestComplex2 extends Complex2 {

	/**
	 * Does nothing.
	 */
	@Test
	public final void testParseXML() {
		
		 File fXmlFile = new File("C:\\New folder\\Sample.xml");
		 ArrayList<String> nodeContentCheck = new ArrayList<String>();
	 	 nodeContentCheck = parseXML(fXmlFile);
	 	 final int numOfNodes = 4;
		
		assertTrue(nodeContentCheck.contains("bk101Rowling, JK"
					+ "Harry Potter and the Deathly HallowsFiction$44.95"));
		assertTrue(nodeContentCheck.contains("bk102Hawking, Stephen"
					+ "A Brief History of TimeScience$5.95"));
		assertTrue(nodeContentCheck.contains("bk103Brown, Dan"
					+ "The Lost SymbolMystery$20.95"));
		assertTrue(nodeContentCheck.contains("bk104Sheldon, Sidney"
					+ "The Doomsday ConspiracySci Fi$10.95"));
		assertFalse(nodeContentCheck.contains("bk105Orwell, George"
					+ "1984Fiction$5.95"));
		assertEquals(nodeContentCheck.size(), numOfNodes);
	}

}
