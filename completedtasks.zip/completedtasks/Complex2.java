package completedtasks;

// **********************
// Parse XML file using JAXP
// Complex-2
// Author: Venktesh Shivam Patel(B-03)
// **********************

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author vshivamp
 *
 */

class Complex2 {

	/**
	 * @param arg
	 * runtime input
	 */
	public static void main(final String[] arg)   {
  
	 File fXmlFile = new File("C:\\New folder\\Sample.xml");
	 Complex2 c2 = new Complex2();
	 c2.parseXML(fXmlFile);
	 
  }
	
	/**
	 * @param fXmlFile
	 * stores the file to be read
	 * @return
	 * ArrayList with node contents
	 */
	
	public ArrayList<String> parseXML(final File fXmlFile) {
		
		
		ArrayList<String> nodeContent = new ArrayList<String>();
		// Using DOM parser
		
		try {
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory
						.newInstance();	
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
		
		
				doc.getDocumentElement().normalize();
				
				NodeList nList = doc.getElementsByTagName("book");
		
		
				// Getting total number of nodes
		
				int numberOfNodes = nList.getLength();
				
				System.out.println("Total number of nodes is "
									+ numberOfNodes + "\n");
				for (int temp = 0; temp < numberOfNodes; temp++) {

					Node nNode = nList.item(temp);
									
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {

						Element eElement = (Element) nNode;
						String eachNode = "";
						
						// Printing the attribute values and tag text
				
					System.out.println("Book id : " + eElement
										.getAttribute("id"));
					eachNode = eachNode + eElement.getAttribute("id");
					
					System.out.println("Author: " + eElement
										.getElementsByTagName("author")
										.item(0).getTextContent());
					eachNode = eachNode + eElement
										.getElementsByTagName("author")
										.item(0).getTextContent();
					
					System.out.println("Title: " + eElement
										.getElementsByTagName("title")
										.item(0).getTextContent());
					eachNode = eachNode + eElement
										.getElementsByTagName("title")
										.item(0).getTextContent();
					
					System.out.println("Genre: " + eElement
										.getElementsByTagName("genre")
										.item(0).getTextContent());
					eachNode = eachNode + eElement
										.getElementsByTagName("genre")
										.item(0).getTextContent();
					
					System.out.println("Price: " + eElement
										.getElementsByTagName("price")
										.item(0).getTextContent() + "\n");
					eachNode = eachNode + eElement
										.getElementsByTagName("price")
										.item(0).getTextContent();

					nodeContent.add(eachNode);
				}	
			} 
				
		}	catch (IOException e) {  
		}	catch (SAXException e) { 
		}	catch (ParserConfigurationException e) { }
			
		return nodeContent;
	}
	
}