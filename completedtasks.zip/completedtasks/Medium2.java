package completedtasks;

// **********************
// List all the files and number of files and directories
// Medium-2
// Author: Venktesh Shivam Patel(B-03)
// **********************

import java.io.File;

/**
 * @author vshivamp
 *
 */

public class Medium2 {


	/**
	 * @param numberOfFiles
	 * stores total files
	 * @param numberOfDirectories
	 * stores total number of directories
	 * 
	 */
	private static int numberOfFiles, numberOfDirectories;
	
	/**
	 * @param dirPath
	 * stores directory path
	 * @param level
	 * stores level of directory
	 */
	
	public final void listDirectory(final String dirPath, final int level) {
		

	    File dir = new File(dirPath);
	    File[] firstLevelFiles = dir.listFiles();
	    
	    // Checking whether directory is empty or not
	    
	    if (firstLevelFiles != null && firstLevelFiles.length > 0) {	
	      
	    	for (File aFile : firstLevelFiles) {
	           
	    		for (int i = 0; i < level; i++) {
	                System.out.print("\t");
	            }
	           
	    		if (aFile.isDirectory()) {
	                System.out.println("[" + aFile.getName() + "]");
	                ++numberOfDirectories;
	                // Entering the sub directory
	               listDirectory(aFile.getAbsolutePath(), level + 1);	
	             
	    		} else {
	    			
	            	++numberOfFiles;
	                System.out.println(aFile.getName());
	            }
	        }
	    }
	    
	}
	    		   
	    		
	            
	    		
	    		
	    
	    /**
	     * @param args
	     * runtime input
	     */
	
	    public static void main(final String[] args) {


	       Medium2 m2 = new Medium2();
	       m2.listDirectory("C:\\New folder", 0);
	       System.out.println("\n*Total number of files " + numberOfFiles);
	       System.out.println("*Total number of directories " 
	       + numberOfDirectories);
	    }
	   
}
