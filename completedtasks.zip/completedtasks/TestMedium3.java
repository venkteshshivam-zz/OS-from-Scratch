package completedtasks;

// *********************
// Extract dates from text files using regular expression(JUnit test)
// Test Medium-3
// Author: Venktesh Shivam Patel(B-03)
// **********************

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;
import java.io.FileReader;
import java.util.ArrayList;
import org.junit.Test;
import java.io.IOException;


/**
 * @author vshivamp
 *
 */
public class TestMedium3 extends Medium3 {

	/**
	 * @throws IOException
	 * handles IO Exception
	 */
	@Test
	public final void testGetDate()throws IOException {
		
		 FileReader fr = new FileReader("C:\\New folder\\T7input.txt");
		 ArrayList<String> listOfDates = new ArrayList<String>();
		 final int validDates = 4;
		 listOfDates = getDate(fr);
		 fr.close();
		 
			assertTrue(listOfDates.contains("14/09/2015"));
			assertTrue(listOfDates.contains("01.01.1901"));
			assertTrue(listOfDates.contains("30/06/2015"));
			assertTrue(listOfDates.contains("31-12-2099"));
			assertFalse(listOfDates.contains("32/13/2100"));
			assertFalse(listOfDates.contains("28/10/2010"));
			assertFalse(listOfDates.contains("01/01/1889"));
			assertEquals(listOfDates.size(), validDates);

	}

}
