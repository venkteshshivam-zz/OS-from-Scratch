package completedtasks;

// **********************
// Concordance problem (list all the words and their line number)
// Complex-1
// Author: Venktesh Shivam Patel(B-03)
// **********************

import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.LineNumberReader;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.Collections;

/**
 * @author vshivamp
 *
 */

class Complex1 { 
	
	/**
	 * empty constructor and not to be called.
	 */
	
	public Complex1() { }
	
	/**
	 * @param arg
	 * runtime input
	 * @throws IOException
	 * handles IO Exceptions
	 */
	
	public static void main(final String[] arg)throws IOException {
		int lineNumber = 1;
		FileReader fr = new FileReader("C:\\New folder\\T9input.txt");
		ArrayList<String> arr = new ArrayList<String>();
		LineNumberReader lr = new LineNumberReader(fr);
		String line = lr.readLine();
		
		while (line != null) {
			
			// Dividing the string into words based on delimiters
			
			StringTokenizer st = new StringTokenizer(line, " .,:;*&[]");
			
			while (st.hasMoreTokens()) {
					arr.add(st.nextToken() + "--" + lineNumber);
			}
			
			line = lr.readLine();
			++lineNumber;
		}
		Collections.sort(arr);
		
		FileWriter writer = new FileWriter("C:\\New folder\\T9output.txt"); 
		for (String str: arr) {
			
		  // Writing word in text file with respective line number
			
		  writer.write(str + System.getProperty("line.separator"));		
		}
		
		fr.close();
		writer.close();
		
	}
	

		 /**
		 * This function is null and void.
		 */
			public void printNothing() {

		
			}	
}
	
