package completedtasks;

// **********************
// Copy contents of one file to another
// Simple-2
// Author: Venktesh Shivam Patel(B-03)
// **********************

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author vshivamp
 *
 */
final class Simple2 {

	/**
	 * empty constructor and not to be called.
	 */
	
	private Simple2() { }

	/**
	 * @param arg
	 * runtime input
	 * @throws IOException
	 * handles IO Exceptions
	 */
	
	public static void main(final String[] arg)throws IOException {
		
		FileReader fr = null;
        FileWriter fw = null;
        
            fr = new FileReader("C:\\New folder\\a.txt");
            fw = new FileWriter("C:\\New folder\\b.txt");
            int character = fr.read();
            
            // Copying contents of file1 to file2 character by character
            
            while (character != -1) {
                fw.write(character);
                character = fr.read();
            }
       
            fr.close();
            fw.close();
	}
	
}
