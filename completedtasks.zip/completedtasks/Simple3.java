package completedtasks;

// **********************
// Count no. of lines, word and characters in text file
// Simple-3
// Author: Venktesh Shivam Patel(B-03)
// **********************

import java.io.IOException;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.util.StringTokenizer;


/**
 * @author vshivamp
 *
 */

final class Simple3 {
	
	/**
	 * empty constructor and not to be called.
	 */
	
	private Simple3() { }
		
	/**
	 * @param arg
	 * runtime input
	 * @throws IOException
	 * handles IO Exceptions
	 */
	
	public static void main(final String[] arg)throws IOException {
		
		
		
		FileReader fr = new FileReader("C:\\New folder\\a.txt");
		LineNumberReader lr = new LineNumberReader(fr);
		
		int lineCount = 0, wordCount = 0, charCount = 0;
		String line = lr.readLine();
		
		// Reading the file line by line
		
		while (line != null) {
		
			lineCount++;
			StringTokenizer st = new StringTokenizer(line, " .,:;*&[]");
			wordCount = wordCount + st.countTokens();
			
			for (int i = 0; i < line.length(); i++) {
				if ((line.charAt(i) != ' ') && (line.charAt(i) != '.')) {
					charCount++;
				}
			}
			
			line = lr.readLine();
		}
		
		fr.close();
		System.out.println(lineCount + "\n" + wordCount + "\n" + charCount);
	
	}
}
